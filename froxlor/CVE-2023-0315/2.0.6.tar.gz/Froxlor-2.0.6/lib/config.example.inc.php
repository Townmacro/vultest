<?php

/**
 * change the options below to either true or false
 */
return [
	'enable_webupdate' => false
];
